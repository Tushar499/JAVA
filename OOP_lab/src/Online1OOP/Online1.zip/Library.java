package Online1OOP;

public class Library {
	private String NameOfLibrarian;
	private int NumberOfBooks;

	public Library() {

	}

	public Library(String NameOfLibrarian, int NumberOfBooks) {
		this.NameOfLibrarian = NameOfLibrarian;
		this.NumberOfBooks = NumberOfBooks;
	}

	public String getNameOfLibrarian() {
		return NameOfLibrarian;
	}

	public void setNameOfLibrarian(String nameOfLibrarian) {
		NameOfLibrarian = nameOfLibrarian;
	}

	public int getNumberOfBooks() {
		return NumberOfBooks;
	}

	public void setNumberOfBooks(int numberOfBooks) {
		NumberOfBooks = numberOfBooks;
	}

	public void PrintAboutLibrary() {
		System.out.println("UIU Library------------------------------------------\r\n");
		System.out.println("Name of the Librarian  \r\n:" + NameOfLibrarian);
		System.out.println("Number of books here   \r\n :" + NumberOfBooks);

	}

	public void LendBook() {
		
			NumberOfBooks--;
			System.out.println("One Book Lended");
			

	if(NumberOfBooks<0){
		System.out.println("No Books there.");
	}
	}
	public void GiveBackBook() {
		NumberOfBooks++;
		System.out.println("One Book Return");

	}

}